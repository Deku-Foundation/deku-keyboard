/*
 * Copyright (C) 2021-2025 The FlorisBoard Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package dev.patrickgold.florisboard.ime.theme

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.text.TextStyle
import dev.patrickgold.florisboard.app.FlorisPreferenceStore
import dev.patrickgold.florisboard.ime.keyboard3.LocalImeController
import dev.patrickgold.florisboard.ime.window.LocalWindowController
import dev.patrickgold.jetpref.datastore.model.collectAsState
import org.florisboard.lib.snygg.ui.ProvideSnyggTheme
import org.florisboard.lib.snygg.ui.rememberSnyggTheme

@Composable
fun FlorisImeTheme(content: @Composable () -> Unit) {
    val imeController = LocalImeController.current
    val themeController = LocalThemeController.current
    val windowController = LocalWindowController.current

    val prefs by FlorisPreferenceStore
    val accentColor by prefs.theme.accentColor.collectAsState()

    val activeTheme by themeController.effectiveTheme.collectAsState()

    val assetResolver = remember(activeTheme) {
        FlorisAssetResolver(activeTheme)
    }
    val snyggTheme = rememberSnyggTheme(activeTheme.stylesheet, assetResolver)
    val windowSpec by windowController.activeWindowSpec.collectAsState()
    val fontScale by remember { derivedStateOf { windowSpec.fontScale } }

//    val imeState by imeController.activeState.collectAsState()
//    val attributes = mapOf(
//        FlorisImeUi.Attr.Mode to imeState.flags.keyboardMode.toString(),
//        FlorisImeUi.Attr.ShiftState to imeState.flags.inputShiftState.toString(),
//    )

    MaterialTheme {
        CompositionLocalProvider(
            LocalTextStyle provides TextStyle.Default,
        ) {
            ProvideSnyggTheme(
                snyggTheme = snyggTheme,
                dynamicAccentColor = accentColor,
                fontSizeMultiplier = fontScale,
                assetResolver = assetResolver,
                rootAttributes = emptyMap(),
                content = content,
                materialYouFlags = activeTheme.config.materialYouFlags
            )
        }
    }
}
