/*
 * Copyright (C) 2021-2025 The FlorisBoard Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package dev.patrickgold.florisboard.ime.keyboard

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.patrickgold.florisboard.app.FlorisPreferenceStore
import dev.patrickgold.florisboard.ime.keyboard3.LocalImeController
import dev.patrickgold.florisboard.ime.nlp.NlpInlineAutofill
import dev.patrickgold.florisboard.ime.smartbar.ExtendedActionsPlacement
import dev.patrickgold.florisboard.ime.smartbar.InlineSuggestionsChipMargin
import dev.patrickgold.florisboard.ime.smartbar.SmartbarLayout
import dev.patrickgold.florisboard.ime.window.LocalWindowController
import dev.patrickgold.jetpref.datastore.model.collectAsState

private val LocalKeyboardRowBaseHeight = compositionLocalOf { 65.dp }
private val LocalSmartbarHeight = compositionLocalOf { 40.dp }

object FlorisImeSizing {
    val keyboardRowBaseHeight: Dp
        @Composable
        @ReadOnlyComposable
        get() = LocalKeyboardRowBaseHeight.current

    val smartbarHeight: Dp
        @Composable
        @ReadOnlyComposable
        get() = LocalSmartbarHeight.current

    @Composable
    fun keyboardUiHeight(): Dp {
        val rowCount by rowCountAsState()
        return keyboardRowBaseHeight * rowCount
    }

    @Composable
    fun rowCountAsState(): State<Int> {
        val imeController = LocalImeController.current
        val imeState by imeController.activeState.collectAsState()
        return remember { derivedStateOf { imeState.effRowCount } }
    }

    @Composable
    fun smartbarRowCountAsState(): State<Int> {
        val prefs by FlorisPreferenceStore
        val smartbarEnabled by prefs.smartbar.enabled.collectAsState()
        val smartbarLayout by prefs.smartbar.layout.collectAsState()
        val extendedActionsExpanded by prefs.smartbar.extendedActionsExpanded.collectAsState()
        val extendedActionsPlacement by prefs.smartbar.extendedActionsPlacement.collectAsState()
        return remember {
            derivedStateOf {
                if (smartbarEnabled) {
                    if (smartbarLayout == SmartbarLayout.SUGGESTIONS_ACTIONS_EXTENDED && extendedActionsExpanded &&
                        extendedActionsPlacement != ExtendedActionsPlacement.OVERLAY_APP_UI) {
                        2
                    } else {
                        1
                    }
                } else {
                    0
                }
            }
        }
    }

    @Composable
    fun smartbarUiHeight(): Dp {
        val smartbarRowCount by smartbarRowCountAsState()
        return smartbarHeight * smartbarRowCount
    }

    @Composable
    fun imeUiHeight(): Dp {
        return keyboardUiHeight() + smartbarUiHeight()
    }
}

@Deprecated("TODO: move logic fully into ImeWindow impl")
@Composable
fun ProvideKeyboardRowBaseHeight(content: @Composable () -> Unit) {
    val windowController = LocalWindowController.current
    val density = LocalDensity.current

    val windowSpec by windowController.activeWindowSpec.collectAsState()

    val heights by remember {
        derivedStateOf {
            val rowHeight = windowSpec.calcRowHeight(windowSpec.props.keyboardHeight)
            val smartbarRowHeight = windowSpec.calcSmartbarRowHeight(windowSpec.props.keyboardHeight)
            rowHeight to smartbarRowHeight
        }
    }
    val (rowHeight, smartbarRowHeight) = heights

    SideEffect {
        val marginV = InlineSuggestionsChipMargin.calculateTopPadding() +
            InlineSuggestionsChipMargin.calculateBottomPadding()
        NlpInlineAutofill.suggestionsChipHeightPx = with(density) {
            (smartbarRowHeight - marginV).roundToPx()
        }
    }

    CompositionLocalProvider(
        LocalKeyboardRowBaseHeight provides rowHeight,
        LocalSmartbarHeight provides smartbarRowHeight,
    ) {
        content()
    }
}
